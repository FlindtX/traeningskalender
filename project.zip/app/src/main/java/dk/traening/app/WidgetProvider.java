package dk.traening.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextPaint;
import android.text.TextUtils;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class WidgetProvider extends AppWidgetProvider {

    private static final String[] DAYS = {"Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"};
    private static final String[] MON = {"jan", "feb", "mar", "apr", "maj", "jun", "jul", "aug", "sep", "okt", "nov", "dec"};

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) {
            update(c, m, id);
        }
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle options) {
        update(c, m, id);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (Intent.ACTION_DATE_CHANGED.equals(i.getAction())) {
            refresh(c);
        }
    }

    public static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, WidgetProvider.class));
        for (int id : ids) {
            update(c, m, id);
        }
    }

    private static void update(Context c, AppWidgetManager m, int id) {
        Bundle o = m.getAppWidgetOptions(id);
        float density = c.getResources().getDisplayMetrics().density;
        boolean land = c.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        int w = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH : AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        int h = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT : AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        if (w <= 0) w = 250;
        if (h <= 0) h = 110;
        float scale = density;
        while (w * scale * h * scale * 4f > 2500000f) {
            scale *= 0.85f;
        }
        Bitmap bmp = Bitmap.createBitmap(Math.max(1, Math.round(w * scale)), Math.max(1, Math.round(h * scale)), Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        cv.scale(scale, scale);
        draw(c, cv, w, h);

        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget);
        rv.setImageViewBitmap(R.id.img, bmp);
        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.img, pi);
        m.updateAppWidget(id, rv);
    }

    private static String ell(String s, Paint p, float width) {
        return TextUtils.ellipsize(s, new TextPaint(p), width, TextUtils.TruncateAt.END).toString();
    }

    private static void draw(Context c, Canvas cv, int W, int H) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        RectF r = new RectF(0, 0, W, H);
        p.setShader(new LinearGradient(0, 0, W, H, 0xFF5B9BFF, 0xFF2347B0, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, 22, 22, p);
        p.setShader(new LinearGradient(0, 0, 0, H * 0.55f, 0x38FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, 22, 22, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1f);
        p.setColor(0x66FFFFFF);
        cv.drawRoundRect(new RectF(0.5f, 0.5f, W - 0.5f, H - 0.5f), 22, 22, p);
        p.setStyle(Paint.Style.FILL);

        JSONObject data;
        try {
            data = new JSONObject(c.getSharedPreferences("w", Context.MODE_PRIVATE).getString("d", "{}"));
        } catch (Exception e) {
            data = new JSONObject();
        }
        JSONObject goal = data.optJSONObject("goal");
        float rightW = goal != null ? 92f : 0f;
        float x0 = 16f;
        float leftW = W - 32f - rightW - (goal != null ? 8f : 0f);

        LocalDate today = LocalDate.now();
        String key = today.getYear() + "-" + today.getMonthValue() + "-" + today.getDayOfMonth();
        String header = DAYS[today.getDayOfWeek().getValue() % 7] + " " + today.getDayOfMonth() + ". " + MON[today.getMonthValue() - 1];

        Object st = data.optJSONObject("done") != null ? data.optJSONObject("done").opt(key) : null;
        boolean isDone = (st instanceof Number) && ((Number) st).intValue() == 1;
        boolean isPlan = "p".equals(st);
        String typeId = data.optJSONObject("types") != null ? data.optJSONObject("types").optString(key, "") : "";
        String typeName = "";
        String typeEmoji = "";
        JSONArray tl = data.optJSONArray("tl");
        if (tl != null) {
            for (int i = 0; i < tl.length(); i++) {
                JSONObject t = tl.optJSONObject(i);
                if (t != null && typeId.equals(t.optString("id"))) {
                    typeName = t.optString("n");
                    typeEmoji = t.optString("e");
                }
            }
        }

        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setColor(0xFFFFFFFF);

        // overskrift
        tp.setTypeface(Typeface.DEFAULT);
        tp.setTextSize(12f);
        tp.setColor(0xBFFFFFFF);
        String hd = header + (isDone ? " · Gennemført" : "");
        cv.drawText(ell(hd, tp, leftW), x0, 28f, tp);

        // titel
        tp.setTypeface(Typeface.DEFAULT_BOLD);
        tp.setTextSize(20f);
        tp.setColor(0xFFFFFFFF);
        String title;
        if (isDone || isPlan) {
            title = (typeEmoji + " " + typeName).trim();
            if (title.length() == 0) {
                title = isDone ? "Træning" : "Planlagt træning";
            }
        } else {
            title = "Ingen træning i dag";
        }
        cv.drawText(ell(title, tp, leftW), x0, 54f, tp);

        // huskeliste
        float y = 78f;
        int maxLines = (int) ((H - y - 6f) / 20f);
        if (maxLines > 3) maxLines = 3;
        JSONObject todosObj = data.optJSONObject("todos");
        JSONArray todos = todosObj != null ? todosObj.optJSONArray(key) : null;
        if ((isDone || isPlan) && todos != null && todos.length() > 0) {
            for (int i = 0; i < todos.length() && i < maxLines; i++) {
                JSONObject t = todos.optJSONObject(i);
                if (t == null) continue;
                boolean d = t.optBoolean("d", false);
                float cy = y - 4.5f;
                if (d) {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFFFFFFF);
                    cv.drawCircle(x0 + 7f, cy, 7f, p);
                    Path ck = new Path();
                    ck.moveTo(x0 + 3.5f, cy);
                    ck.lineTo(x0 + 6f, cy + 2.6f);
                    ck.lineTo(x0 + 10.5f, cy - 2.6f);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(1.8f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setStrokeJoin(Paint.Join.ROUND);
                    p.setColor(0xFF2F6FE4);
                    cv.drawPath(ck, p);
                } else {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(1.6f);
                    p.setColor(0xCCFFFFFF);
                    cv.drawCircle(x0 + 7f, cy, 6.2f, p);
                }
                p.setStyle(Paint.Style.FILL);
                tp.setTypeface(Typeface.DEFAULT);
                tp.setTextSize(14f);
                tp.setColor(d ? 0x99FFFFFF : 0xFFFFFFFF);
                tp.setStrikeThruText(d);
                cv.drawText(ell(t.optString("t"), tp, leftW - 24f), x0 + 22f, y, tp);
                tp.setStrikeThruText(false);
                y += 20f;
            }
        } else if (!isDone && !isPlan) {
            tp.setTypeface(Typeface.DEFAULT);
            tp.setTextSize(13f);
            tp.setColor(0xBFFFFFFF);
            cv.drawText(ell("Tryk for at åbne kalenderen", tp, leftW), x0, y, tp);
        } else if (isDone) {
            tp.setTypeface(Typeface.DEFAULT);
            tp.setTextSize(13f);
            tp.setColor(0xBFFFFFFF);
            cv.drawText("Godt gået!", x0, y, tp);
        } else {
            tp.setTypeface(Typeface.DEFAULT);
            tp.setTextSize(13f);
            tp.setColor(0xBFFFFFFF);
            cv.drawText("Planlagt", x0, y, tp);
        }

        // mål
        if (goal != null) {
            long days = 0;
            try {
                String[] ps = goal.optString("d").split("-");
                LocalDate gd = LocalDate.of(Integer.parseInt(ps[0]), Integer.parseInt(ps[1]), Integer.parseInt(ps[2]));
                days = ChronoUnit.DAYS.between(today, gd);
            } catch (Exception e) {
                days = 0;
            }
            double f = goal.optDouble("f", 0);
            if (f < 0) f = 0;
            if (f > 1) f = 1;
            float cx = W - 16f - 46f;
            float rad = Math.min(29f, (H - 16f - 22f) / 2f - 4f);
            if (rad < 16f) rad = 16f;
            float cy = 14f + rad + 4f;
            RectF arc = new RectF(cx - rad, cy - rad, cx + rad, cy + rad);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(7f);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(0x4DFFFFFF);
            cv.drawArc(arc, 0, 360, false, p);
            p.setColor(0xFFFFFFFF);
            if (f > 0.005) {
                cv.drawArc(arc, -90, (float) (360 * f), false, p);
            }
            p.setStyle(Paint.Style.FILL);
            tp.setTextAlign(Paint.Align.CENTER);
            tp.setTypeface(Typeface.DEFAULT_BOLD);
            tp.setColor(0xFFFFFFFF);
            tp.setTextSize(rad > 24f ? 20f : 16f);
            cv.drawText(String.valueOf(days), cx, cy + 2f, tp);
            tp.setTypeface(Typeface.DEFAULT);
            tp.setTextSize(9f);
            tp.setColor(0xBFFFFFFF);
            cv.drawText(days == 1 ? "dag" : "dage", cx, cy + 12f, tp);
            tp.setTypeface(Typeface.DEFAULT_BOLD);
            tp.setTextSize(11f);
            tp.setColor(0xFFFFFFFF);
            String gn = (goal.optString("e") + " " + goal.optString("n")).trim();
            cv.drawText(ell(gn, tp, 92f), cx, cy + rad + 17f, tp);
            tp.setTextAlign(Paint.Align.LEFT);
        }
    }
}
